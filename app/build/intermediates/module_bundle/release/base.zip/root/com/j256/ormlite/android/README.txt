This package provides the Android specific functionality.  You will also need to download the
ormlite-core package as well.  Users that are connecting to SQL databases via JDBC connections
should download the ormlite-jdbc package instead of this Android one.

For more information, see the online documentation on the home page:

   http://ormlite.com/

Sources can be found online via Github:

   https://github.com/j256/ormlite-android

Enjoy,
Gray Watson
